from django.contrib import admin
from .models import *
from .api_call import get_obj
# Register your models here.
def get_data(modeladmin, request, queryset):
    get_obj(queryset)
get_data.short_description = "Get data"

def change_status(modeladmin, request, queryset):
    for obj in queryset:
        obj.status  = False
        obj.save()

class CityAdmin(admin.ModelAdmin):
    list_display = ('city_id','city_name','state')
    list_filter = ('state',)
    search_fields = ('city_name',)
    list_per_page = 50

class PlaceAdmin(admin.ModelAdmin):
    list_display = ('place_name','type','city')
    list_filter = ('type',)
    search_fields = ('place_name',)
    list_per_page = 50

class KeywordAdmin(admin.ModelAdmin):
    list_display = ('keyword','status','file','no_of_places')
    list_filter = ('file','status')
    list_per_page = 50
    actions = [get_data,change_status]

    def no_of_places(self,obj):
        return obj.place.count()

class SeachAdmin(admin.ModelAdmin):
    list_display = ('name','status','no_of_keywords','api_key')
    list_per_page = 50
    list_filter  = ('status',)
    actions = [change_status]
    def no_of_keywords(self,obj):
        return obj.keyword.count()
    no_of_keywords.short_description = "No of keywords"
    
admin.site.register(State)
admin.site.register(City,CityAdmin)
admin.site.register(Place,PlaceAdmin)
admin.site.register(Search_Upload,SeachAdmin)
admin.site.register(Keyword,KeywordAdmin)
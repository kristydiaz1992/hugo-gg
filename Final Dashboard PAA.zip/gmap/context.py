from .models import *
from django.db.models import Q
def send_types(request):
    if not request.user.is_authenticated:
        return {'types': []}
    types = Search_Upload.objects.all()
    counts = []
    for file in types:
        if Keyword.objects.filter(file=file).exists():
            query = Q()
            for i in Keyword.objects.filter(file=file):
                query |= Q(type=i)
            counts.append(Place.objects.filter(query).count())
        else:
            counts.append(0)
    count = dict(zip(types, counts))
    return {'types': count}
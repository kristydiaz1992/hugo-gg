from django.db import models
from django.core.validators import FileExtensionValidator
# Create your models here.
class State(models.Model):
    state_id = models.AutoField(primary_key=True)
    state_name = models.CharField(max_length=100)
    def __str__(self):
        return self.state_name

class City(models.Model):
    city_id = models.AutoField(primary_key=True)
    city_name = models.CharField(max_length=100)
    state = models.ForeignKey(State, on_delete=models.CASCADE)
    def __str__(self):
        return self.city_name

class Search_Upload(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    file = models.FileField(upload_to='upload files/', validators=[FileExtensionValidator(allowed_extensions=['txt'])])
    api_key = models.CharField(max_length=100,default="")
    status = models.BooleanField(default=False)
    def __str__(self):
        return self.name

class Keyword(models.Model):
    id = models.AutoField(primary_key=True)
    keyword = models.CharField(max_length=100)
    file = models.ForeignKey(Search_Upload, on_delete=models.CASCADE,related_name='keyword',null=True,blank=True)
    status = models.BooleanField(default=False)
    def __str__(self):
        return self.keyword

class Place(models.Model):
    id = models.AutoField(primary_key=True)
    gmap_id = models.CharField(max_length=70)
    place_name = models.CharField(max_length=250)
    address = models.CharField(max_length=250,default="NA")
    pincode = models.CharField(max_length=20,default="NA")
    phone = models.CharField(max_length=20,default="NA")
    rating = models.FloatField(default=0)
    reviews = models.IntegerField(default=0)
    photo = models.CharField(max_length=250,null=True)
    type = models.ForeignKey(Keyword, on_delete=models.CASCADE,related_name='place')
    city = models.ForeignKey(City, on_delete=models.CASCADE,related_name='places')
    paa_status = models.BooleanField(default=False)
    def __str__(self):
        return self.place_name
    
 
class Running_Task(models.Model):
    task_id = models.AutoField(primary_key=True)
    status = models.BooleanField(default=False)
    type = models.ForeignKey(Search_Upload, on_delete=models.CASCADE)

    

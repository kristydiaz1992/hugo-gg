from .models import *
import contextlib
import googlemaps
from bs4 import BeautifulSoup
import time
from threading import Thread
from django.core.paginator import Paginator

def call_place_api(key,city):
    with contextlib.suppress(Exception):
        api_key =key.file.api_key
        search = key.keyword
        # exists_city = .values('city')
        # print(type(exists_city))
        for i in city:
            if not key.place.filter(city=i).exists():
                res = googlemaps.Client(key=api_key).places(f"{search} in {i.city_name} , {i.state.state_name}")
                places = res.get("results")
                for j in places:
                    place = Place(type=key,city=i,place_name=j['name'],gmap_id = j['place_id'])
                    with contextlib.suppress(Exception):
                        place.address = j['formatted_address']
                        place.pincode = j['formatted_address'].split(',')[-2]
                    with contextlib.suppress(Exception):
                        place.phone = j['formatted_phone_number']
                    with contextlib.suppress(Exception):
                        place.rating = j['rating']
                    with contextlib.suppress(Exception):
                        place.reviews = j['user_ratings_total']
                    with contextlib.suppress(Exception):
                        place.photo = BeautifulSoup(i['photos'][0]['html_attributions'][0], 'html.parser').find('a').attrs['href']
                    place.save()

def create_thread(key):
    thread = []
    city_qs = Paginator(City.objects.get_queryset(), 646)
    for page_no in city_qs.page_range:
        current_page = city_qs.get_page(page_no)
        t = Thread(target=call_place_api, args=(key,current_page.object_list))
        t.start()
        thread.append(t)
    for t in thread:
        t.join()
    key.status = True
    key.save()
    time.sleep(1)

def get_obj(obj):
    if list := [i for i in obj if i.status == False]:
        if len(list)>=2:
            max_go = len(list)-len(list)//2
            for i in range(0,max_go,2):
                    t = Thread(target=create_thread,args=(list[i],))
                    t2 = Thread(target=create_thread,args=(list[i+1],))
                    t.start()
                    t2.start()
                    t.join()
                    t2.join()
            create_thread(list[max_go])
        else:
            create_thread(list[0])
    
            
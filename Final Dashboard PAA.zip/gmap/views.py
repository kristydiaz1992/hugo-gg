from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
import sqlite3
from .models import *
import time
from django.db.models import Q
from threading import Thread
from .api_call import get_obj
from django.core.paginator import Paginator

# mydb = mysql.connect(host="localhost", user="root", passwd="", db="housing")
# mycursor  =mydb.cursor()

def index(request):
    conn = sqlite3.connect('db.sqlite3')
    mycursor = conn.cursor()
    mycursor.execute("SELECT * FROM gmap_state")
    states = mycursor.fetchall()
    for i in states:
        if not State.objects.filter(state_id=i[0]).exists():
            state = State(state_id=i[0], state_name=i[1])
            state.save()
    return HttpResponse("state saved")

def save_city(citys):
    for i in citys:
        if not City.objects.filter(city_id=i[0]).exists():
            city = City(city_id=i[0],city_name=i[1],state =State.objects.get(state_id=i[2]))
            city.save()
            print(city.city_id)

def city(request):
    conn = sqlite3.connect('db.sqlite3')
    mycursor = conn.cursor()    
    mycursor.execute("SELECT * FROM gmap_city")
    citys = mycursor.fetchall()
    city_qs = Paginator(citys, 646)
    thread=[]
    for page_no in city_qs.page_range:
        current_page = city_qs.get_page(page_no)
        t = Thread(target=save_city, args=(current_page.object_list,))
        t.start()
        thread.append(t)
    for t in thread:
        t.join()
    return HttpResponse("city saved")



def get_place(request):
    if request.method != 'GET':
        return 
    id = request.GET.get('type')
    type = Search_Upload.objects.get(id=id)
    type.status = True
    type.save()
    with open(type.file.path, 'r') as f:
        lines = f.readlines()
        for line in lines:
            if line := line.strip():
                key,create = Keyword.objects.get_or_create(file=type,keyword=line)
                key.save()
        get_obj(Keyword.objects.filter(file=type))
    return JsonResponse({"status": "success"})
    

def info(request):
    if request.method != 'GET':
        return
    id = request.GET.get('id')
    file = Search_Upload.objects.get(id=id)
    
    if Keyword.objects.filter(file=file).exists():
        query = Q()
        for i in Keyword.objects.filter(file=file):
            query |= Q(type=i)
        counts = Place.objects.filter(query).count()
    else:
        counts = 0
    return JsonResponse({"status": "success", 'count': counts})
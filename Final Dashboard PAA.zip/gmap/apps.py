from django.apps import AppConfig


class GmapConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gmap'

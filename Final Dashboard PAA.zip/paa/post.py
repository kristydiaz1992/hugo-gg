import psycopg2  #pip install psycopg2

conn = psycopg2.connect(database="postgres", user="postgres", host = 'database-1.ckeuv503ggkm.us-east-1.rds.amazonaws.com',
                        password="popnda69", port="5432")
cursor = conn.cursor()
